//
// impressionistDoc.h
//
// header file for Doc
//

#ifndef ImpressionistDoc_h
#define ImpressionistDoc_h

#include "Bitmap.h"
#include "Impressionist.h"

const int UNDO_LEVEL = 5;

class ImpressionistUI;

class ImpressionistDoc {
public:
	ImpressionistDoc();

	void setUI(ImpressionistUI* ui); // Assign the UI to use

	int loadImage(char* iname); // called by the UI to load image
	int saveImage(char* iname); // called by the UI to save image
	int loadDissolveImage(char* iname);
	int loadMuralImage(char* iname);
	int loadAlphaMapImage(char* iname);

	int clearCanvas();			 // called by the UI to clear the drawing canvas
	void setBrushType(int type); // called by the UI to set the brushType
	int getSize();				 // get the UI size
	void setSize(int size);		 // set the UI size
	char* getImageName();		 // get the current image name
	float getAlpha();
	void setAlpha(float alpha);
	void setStrokeType(int type); // called by the UI to set the StrokeType
	int getStrokeType();

	void recordPainting();
	void undo();
	void dissolveImage();


	// Attributes
public:
	// Dimensions of original window.
	int m_nWidth, m_nHeight;
	// Dimensions of the paint window.
	int m_nPaintWidth, m_nPaintHeight;

	int m_nAlphaWidth, m_nAlphaHeight;
	// Bitmaps for original image and painting.
	unsigned char* m_ucBitmap;

	unsigned char* m_ucPainting;

	unsigned char* m_ucDissolve;

	unsigned char* m_ucAlphaMap;

	int m_pStroke;

	// The current active brush.
	ImpBrush* m_pCurrentBrush;
	ImpBrush* m_pDirectionLine;
	// Size of the brush.
	int m_nSize;

	ImpressionistUI* m_pUI;

	// Operations
public:
	// Get the color of the original picture at the specified coord
	GLubyte* GetOriginalPixel(int x, int y);
	// Get the color of the original picture at the specified point
	GLubyte* GetOriginalPixel(const Point p);

private:
	int undo_header;
	unsigned char* m_last_ucPainting[UNDO_LEVEL];
	char m_imageName[256];
};

extern void MessageBox(char* message);

#endif
